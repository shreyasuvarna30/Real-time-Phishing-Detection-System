"""
train.py — Train and save the PhishGuard ML model.

Run once before starting the Flask app:
    python train.py

Uses a Random Forest classifier trained on synthetic URL features
that mirror real phishing dataset distributions (e.g. UCI Phishing Websites).
Swap in a real dataset CSV for production-grade accuracy.
"""

import numpy as np
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline

from model import extract_features, features_to_vector

np.random.seed(42)
N = 3000  # samples per class


def make_legit_samples(n):
    samples = []
    for _ in range(n):
        f = {
            'is_https': np.random.choice([1, 1, 1, 0], p=[0.9, 0.0, 0.0, 0.1]),
            'url_length': int(np.random.normal(45, 15)),
            'hostname_length': int(np.random.normal(12, 5)),
            'path_length': int(np.random.normal(10, 8)),
            'query_length': int(np.random.normal(5, 8)),
            'has_ip_address': 0,
            'subdomain_count': int(np.random.choice([0, 1, 2], p=[0.5, 0.4, 0.1])),
            'suspicious_tld': 0,
            'has_phishing_keyword': int(np.random.random() < 0.05),
            'at_symbol': 0,
            'double_slash_redirect': 0,
            'dash_in_hostname': int(np.random.random() < 0.1),
            'dot_count': int(np.random.choice([1, 2, 3], p=[0.5, 0.4, 0.1])),
            'digit_ratio': round(np.random.uniform(0, 0.1), 3),
            'url_entropy': round(np.random.normal(3.8, 0.4), 3),
            'is_trusted_domain': int(np.random.random() < 0.3),
            'is_shortened': int(np.random.random() < 0.02),
            'has_encoded_chars': int(np.random.random() < 0.1),
            'has_non_std_port': 0,
        }
        f = {k: max(0, v) if isinstance(v, (int, float)) else v for k, v in f.items()}
        samples.append(f)
    return samples


def make_phishing_samples(n):
    samples = []
    for _ in range(n):
        f = {
            'is_https': int(np.random.random() < 0.25),
            'url_length': int(np.random.normal(90, 25)),
            'hostname_length': int(np.random.normal(28, 10)),
            'path_length': int(np.random.normal(35, 20)),
            'query_length': int(np.random.normal(20, 15)),
            'has_ip_address': int(np.random.random() < 0.3),
            'subdomain_count': int(np.random.choice([1, 2, 3, 4], p=[0.2, 0.3, 0.3, 0.2])),
            'suspicious_tld': int(np.random.random() < 0.6),
            'has_phishing_keyword': int(np.random.random() < 0.7),
            'at_symbol': int(np.random.random() < 0.2),
            'double_slash_redirect': int(np.random.random() < 0.3),
            'dash_in_hostname': int(np.random.random() < 0.6),
            'dot_count': int(np.random.choice([2, 3, 4, 5], p=[0.2, 0.3, 0.3, 0.2])),
            'digit_ratio': round(np.random.uniform(0.1, 0.5), 3),
            'url_entropy': round(np.random.normal(4.5, 0.5), 3),
            'is_trusted_domain': 0,
            'is_shortened': int(np.random.random() < 0.15),
            'has_encoded_chars': int(np.random.random() < 0.4),
            'has_non_std_port': int(np.random.random() < 0.2),
        }
        f = {k: max(0, v) if isinstance(v, (int, float)) else v for k, v in f.items()}
        samples.append(f)
    return samples


def main():
    print("Generating training data...")
    legit = make_legit_samples(N)
    phish = make_phishing_samples(N)

    X = np.array([features_to_vector(f) for f in legit + phish])
    y = np.array([0] * N + [1] * N)  # 0 = legit, 1 = phishing

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    print("Training Random Forest classifier...")
    pipeline = Pipeline([
        ('scaler', StandardScaler()),
        ('clf', RandomForestClassifier(
            n_estimators=200,
            max_depth=12,
            min_samples_split=5,
            min_samples_leaf=2,
            class_weight='balanced',
            random_state=42,
            n_jobs=-1
        ))
    ])

    pipeline.fit(X_train, y_train)

    y_pred = pipeline.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    print(f"\nTest Accuracy: {acc:.4f}")
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred, target_names=['Legitimate', 'Phishing']))

    joblib.dump(pipeline, 'model.pkl')
    print("\nModel saved to model.pkl")
    print("You can now run: python app.py")


if __name__ == '__main__':
    main()
