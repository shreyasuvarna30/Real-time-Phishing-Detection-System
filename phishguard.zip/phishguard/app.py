"""
app.py — PhishGuard Flask Application
"""

import os
import joblib
import numpy as np
from datetime import datetime

from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_login import (
    LoginManager, UserMixin, login_user, logout_user,
    login_required, current_user
)
from flask_bcrypt import Bcrypt

from model import extract_features, features_to_vector

# ── App setup ────────────────────────────────────────────────────────────────

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'phishguard-dev-secret-change-in-prod')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///phishguard.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
bcrypt = Bcrypt(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Please sign in to continue.'

# ── Load ML model ────────────────────────────────────────────────────────────

MODEL_PATH = os.path.join(os.path.dirname(__file__), 'model.pkl')

try:
    model = joblib.load(MODEL_PATH)
    print("✓ Model loaded from model.pkl")
except FileNotFoundError:
    model = None
    print("⚠  model.pkl not found — run `python train.py` first")

# ── Database models ──────────────────────────────────────────────────────────

class User(UserMixin, db.Model):
    id         = db.Column(db.Integer, primary_key=True)
    name       = db.Column(db.String(120), nullable=False)
    email      = db.Column(db.String(120), unique=True, nullable=False)
    password   = db.Column(db.String(200), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    scans      = db.relationship('ScanResult', backref='user', lazy=True)

    @property
    def initials(self):
        parts = self.name.strip().split()
        return ''.join(p[0].upper() for p in parts[:2])

    @property
    def scan_count(self):
        return len(self.scans)

    @property
    def phishing_count(self):
        return sum(1 for s in self.scans if s.verdict == 'phishing')

    @property
    def safe_count(self):
        return sum(1 for s in self.scans if s.verdict == 'safe')


class ScanResult(db.Model):
    id         = db.Column(db.Integer, primary_key=True)
    user_id    = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    url        = db.Column(db.String(2000), nullable=False)
    verdict    = db.Column(db.String(20), nullable=False)   # safe / suspicious / phishing
    risk_score = db.Column(db.Integer, nullable=False)
    confidence = db.Column(db.Float, nullable=False)
    scanned_at = db.Column(db.DateTime, default=datetime.utcnow)


@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))


# ── Auth routes ──────────────────────────────────────────────────────────────

@app.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('scanner'))
    return redirect(url_for('login'))


@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('scanner'))
    if request.method == 'POST':
        email    = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        user = User.query.filter_by(email=email).first()
        if user and bcrypt.check_password_hash(user.password, password):
            login_user(user)
            return redirect(url_for('scanner'))
        flash('Invalid email or password.', 'error')
    return render_template('login.html')


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if current_user.is_authenticated:
        return redirect(url_for('scanner'))
    if request.method == 'POST':
        name     = request.form.get('name', '').strip()
        email    = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')

        if not name or not email or not password:
            flash('All fields are required.', 'error')
        elif len(password) < 6:
            flash('Password must be at least 6 characters.', 'error')
        elif User.query.filter_by(email=email).first():
            flash('An account with this email already exists.', 'error')
        else:
            hashed = bcrypt.generate_password_hash(password).decode('utf-8')
            user = User(name=name, email=email, password=hashed)
            db.session.add(user)
            db.session.commit()
            login_user(user)
            return redirect(url_for('scanner'))
    return render_template('signup.html')


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))


# ── Scanner route ─────────────────────────────────────────────────────────────

@app.route('/scanner')
@login_required
def scanner():
    history = (
        ScanResult.query
        .filter_by(user_id=current_user.id)
        .order_by(ScanResult.scanned_at.desc())
        .limit(10)
        .all()
    )
    return render_template('scanner.html', history=history)


# ── Predict API ───────────────────────────────────────────────────────────────

@app.route('/predict', methods=['POST'])
@login_required
def predict():
    data = request.get_json()
    url  = (data or {}).get('url', '').strip()

    if not url:
        return jsonify({'error': 'URL is required'}), 400

    if model is None:
        return jsonify({'error': 'Model not loaded. Run python train.py first.'}), 500

    features     = extract_features(url)
    vector       = features_to_vector(features).reshape(1, -1)
    prediction   = int(model.predict(vector)[0])
    proba        = model.predict_proba(vector)[0]
    confidence   = round(float(proba[prediction]) * 100, 1)
    phish_proba  = round(float(proba[1]) * 100, 1)
    risk_score   = int(phish_proba)

    if prediction == 1:
        verdict = 'phishing'
    elif phish_proba >= 30:
        verdict = 'suspicious'
    else:
        verdict = 'safe'

    # Save to DB
    scan = ScanResult(
        user_id    = current_user.id,
        url        = url,
        verdict    = verdict,
        risk_score = risk_score,
        confidence = confidence,
    )
    db.session.add(scan)
    db.session.commit()

    return jsonify({
        'url':        url,
        'verdict':    verdict,
        'risk_score': risk_score,
        'confidence': confidence,
        'features':   features,
    })


# ── History API ───────────────────────────────────────────────────────────────

@app.route('/history')
@login_required
def history():
    scans = (
        ScanResult.query
        .filter_by(user_id=current_user.id)
        .order_by(ScanResult.scanned_at.desc())
        .all()
    )
    return render_template('history.html', scans=scans)


# ── Run ───────────────────────────────────────────────────────────────────────

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        print("✓ Database ready")
    app.run(debug=True, port=5000)
