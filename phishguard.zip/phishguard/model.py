import re
import urllib.parse
import numpy as np
from datetime import datetime


SUSPICIOUS_TLDS = {
    'tk', 'ml', 'ga', 'cf', 'gq', 'ru', 'xyz', 'top', 'work',
    'click', 'link', 'online', 'site', 'website', 'space', 'pw'
}

PHISHING_KEYWORDS = {
    'paypal', 'ebay', 'amazon', 'apple', 'google', 'microsoft',
    'bank', 'secure', 'account', 'login', 'signin', 'verify',
    'update', 'confirm', 'suspend', 'billing', 'password', 'credential'
}

TRUSTED_DOMAINS = {
    'google.com', 'youtube.com', 'facebook.com', 'twitter.com',
    'github.com', 'microsoft.com', 'apple.com', 'amazon.com',
    'wikipedia.org', 'linkedin.com', 'instagram.com', 'reddit.com'
}


def extract_features(url: str) -> dict:
    """
    Extract ML features from a URL.
    Returns a dict of feature_name -> value.
    """
    features = {}

    # Normalize
    if not url.startswith(('http://', 'https://')):
        url = 'http://' + url

    try:
        parsed = urllib.parse.urlparse(url)
        hostname = parsed.netloc or parsed.path
        hostname = hostname.lower().split(':')[0]  # remove port
        path = parsed.path + ('?' + parsed.query if parsed.query else '')
    except Exception:
        return _empty_features()

    # --- Protocol ---
    features['is_https'] = int(parsed.scheme == 'https')

    # --- URL length features ---
    features['url_length'] = len(url)
    features['hostname_length'] = len(hostname)
    features['path_length'] = len(path)
    features['query_length'] = len(parsed.query)

    # --- IP address as hostname ---
    features['has_ip_address'] = int(bool(
        re.match(r'^\d{1,3}(\.\d{1,3}){3}$', hostname)
    ))

    # --- Subdomain depth ---
    parts = hostname.split('.')
    features['subdomain_count'] = max(0, len(parts) - 2)

    # --- TLD suspicion ---
    tld = parts[-1] if parts else ''
    features['suspicious_tld'] = int(tld in SUSPICIOUS_TLDS)

    # --- Keyword in hostname ---
    features['has_phishing_keyword'] = int(any(
        kw in hostname for kw in PHISHING_KEYWORDS
    ))

    # --- Special characters ---
    features['at_symbol'] = int('@' in url)
    features['double_slash_redirect'] = int(url.count('//') > 1)
    features['dash_in_hostname'] = int('-' in hostname)
    features['dot_count'] = hostname.count('.')

    # --- Digit ratio in hostname ---
    digits = sum(c.isdigit() for c in hostname)
    features['digit_ratio'] = round(digits / max(len(hostname), 1), 3)

    # --- URL entropy (randomness) ---
    features['url_entropy'] = round(_entropy(url), 3)

    # --- Trusted domain ---
    root_domain = '.'.join(parts[-2:]) if len(parts) >= 2 else hostname
    features['is_trusted_domain'] = int(root_domain in TRUSTED_DOMAINS)

    # --- Shortened URL patterns ---
    shorteners = {'bit.ly', 'tinyurl.com', 't.co', 'goo.gl', 'ow.ly', 'is.gd'}
    features['is_shortened'] = int(root_domain in shorteners)

    # --- Encoded characters ---
    features['has_encoded_chars'] = int('%' in url)

    # --- Port usage ---
    features['has_non_std_port'] = int(bool(
        parsed.port and parsed.port not in (80, 443)
    ))

    return features


def features_to_vector(features: dict) -> np.ndarray:
    """Convert feature dict to numpy array for model input."""
    order = [
        'is_https', 'url_length', 'hostname_length', 'path_length',
        'query_length', 'has_ip_address', 'subdomain_count',
        'suspicious_tld', 'has_phishing_keyword', 'at_symbol',
        'double_slash_redirect', 'dash_in_hostname', 'dot_count',
        'digit_ratio', 'url_entropy', 'is_trusted_domain',
        'is_shortened', 'has_encoded_chars', 'has_non_std_port'
    ]
    return np.array([features.get(k, 0) for k in order], dtype=float)


def _entropy(text: str) -> float:
    """Shannon entropy of a string."""
    if not text:
        return 0.0
    prob = [text.count(c) / len(text) for c in set(text)]
    return -sum(p * np.log2(p) for p in prob if p > 0)


def _empty_features() -> dict:
    return {k: 0 for k in [
        'is_https', 'url_length', 'hostname_length', 'path_length',
        'query_length', 'has_ip_address', 'subdomain_count',
        'suspicious_tld', 'has_phishing_keyword', 'at_symbol',
        'double_slash_redirect', 'dash_in_hostname', 'dot_count',
        'digit_ratio', 'url_entropy', 'is_trusted_domain',
        'is_shortened', 'has_encoded_chars', 'has_non_std_port'
    ]}
