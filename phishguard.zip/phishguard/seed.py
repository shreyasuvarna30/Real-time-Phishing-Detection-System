"""
seed.py — Creates the demo user account.
Run after train.py:
    python seed.py
"""

from app import app, db, bcrypt
from app import User

with app.app_context():
    db.create_all()
    if not User.query.filter_by(email='demo@phishguard.io').first():
        hashed = bcrypt.generate_password_hash('demo123').decode('utf-8')
        demo = User(name='Demo User', email='demo@phishguard.io', password=hashed)
        db.session.add(demo)
        db.session.commit()
        print("✓ Demo user created: demo@phishguard.io / demo123")
    else:
        print("✓ Demo user already exists")
